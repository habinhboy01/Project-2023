<?php

/**
 * Plugin Name: Portfolio  Manager
 * Description: Customize WordPress with Custom Taxonomies.
 * Version: 1.0 
 * Author: VanKai 
 * Author URI: http://vankai.com 
 * License: GPLv2 or later 
 */


// custom post type
//require plugin_dir_path(__DIR__)  . '/ql-portfolio/post-type/CPT.php';
// // Portfolio custom post type
require plugin_dir_path(__DIR__) . '/ql-portfolio/post-type/register-portfolio.php';
